"use client"

import { useState } from "react"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

export function AppointmentCalendar() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  // Exemplo de dias com agendamentos
  const appointmentDays = [
    new Date(2024, 2, 15),
    new Date(2024, 2, 16),
    new Date(2024, 2, 20),
    new Date(2024, 2, 22),
    new Date(2024, 2, 25),
    new Date(2024, 2, 28),
  ]

  // Função para verificar se um dia tem agendamentos
  const hasAppointments = (day: Date) => {
    return appointmentDays.some(
      (d) => d.getDate() === day.getDate() && d.getMonth() === day.getMonth() && d.getFullYear() === day.getFullYear(),
    )
  }

  return (
    <div className="space-y-4">
      <Calendar
        mode="single"
        selected={date}
        onSelect={setDate}
        className="rounded-md border"
        modifiersClassNames={{
          selected: "bg-primary text-primary-foreground",
        }}
        components={{
          DayContent: ({ date, ...props }) => (
            <div {...props} className={cn("relative flex h-9 w-9 items-center justify-center", props.className)}>
              {date.getDate()}
              {hasAppointments(date) && <div className="absolute bottom-1 h-1 w-1 rounded-full bg-primary"></div>}
            </div>
          ),
        }}
      />

      {date && (
        <Card>
          <CardContent className="p-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="font-medium">
                  {date.toLocaleDateString("pt-BR", {
                    weekday: "long",
                    day: "numeric",
                    month: "long",
                  })}
                </h3>
                <Badge variant="outline" className="bg-primary/10">
                  {hasAppointments(date) ? "4 agendamentos" : "Livre"}
                </Badge>
              </div>
              {hasAppointments(date) && (
                <div className="space-y-2 pt-2">
                  <div className="flex items-center justify-between rounded-md border p-2">
                    <div>
                      <p className="font-medium">Ana Silva</p>
                      <p className="text-xs text-muted-foreground">Limpeza de Pele</p>
                    </div>
                    <Badge>10:00</Badge>
                  </div>
                  <div className="flex items-center justify-between rounded-md border p-2">
                    <div>
                      <p className="font-medium">Carla Oliveira</p>
                      <p className="text-xs text-muted-foreground">Massagem Relaxante</p>
                    </div>
                    <Badge>13:30</Badge>
                  </div>
                  <div className="flex items-center justify-between rounded-md border p-2">
                    <div>
                      <p className="font-medium">Mariana Costa</p>
                      <p className="text-xs text-muted-foreground">Depilação</p>
                    </div>
                    <Badge>15:00</Badge>
                  </div>
                  <div className="flex items-center justify-between rounded-md border p-2">
                    <div>
                      <p className="font-medium">Juliana Mendes</p>
                      <p className="text-xs text-muted-foreground">Manicure e Pedicure</p>
                    </div>
                    <Badge>17:30</Badge>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

