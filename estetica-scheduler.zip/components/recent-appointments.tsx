import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

const recentAppointments = [
  {
    id: 1,
    client: {
      name: "Mariana Costa",
      avatar: "/avatars/01.png",
      initials: "MC",
    },
    service: "Depilação",
    date: "Hoje, 15:00",
    status: "confirmado",
  },
  {
    id: 2,
    client: {
      name: "Juliana Mendes",
      avatar: "/avatars/02.png",
      initials: "JM",
    },
    service: "Manicure e Pedicure",
    date: "Hoje, 17:30",
    status: "confirmado",
  },
  {
    id: 3,
    client: {
      name: "Carla Oliveira",
      avatar: "/avatars/03.png",
      initials: "CO",
    },
    service: "Massagem Relaxante",
    date: "Amanhã, 13:30",
    status: "pendente",
  },
  {
    id: 4,
    client: {
      name: "Ana Silva",
      avatar: "/avatars/04.png",
      initials: "AS",
    },
    service: "Limpeza de Pele",
    date: "Amanhã, 10:00",
    status: "confirmado",
  },
  {
    id: 5,
    client: {
      name: "Patrícia Lima",
      avatar: "/avatars/05.png",
      initials: "PL",
    },
    service: "Design de Sobrancelhas",
    date: "15/03, 14:00",
    status: "cancelado",
  },
]

export function RecentAppointments() {
  return (
    <div className="space-y-8">
      {recentAppointments.map((appointment) => (
        <div key={appointment.id} className="flex items-center">
          <Avatar className="h-9 w-9">
            <AvatarImage src={appointment.client.avatar} alt="Avatar" />
            <AvatarFallback>{appointment.client.initials}</AvatarFallback>
          </Avatar>
          <div className="ml-4 space-y-1">
            <p className="text-sm font-medium leading-none">{appointment.client.name}</p>
            <p className="text-sm text-muted-foreground">{appointment.service}</p>
          </div>
          <div className="ml-auto flex flex-col items-end">
            <p className="text-sm">{appointment.date}</p>
            <Badge
              variant="outline"
              className={cn(
                "mt-1",
                appointment.status === "confirmado" && "bg-green-500/10 text-green-500",
                appointment.status === "pendente" && "bg-yellow-500/10 text-yellow-500",
                appointment.status === "cancelado" && "bg-red-500/10 text-red-500",
              )}
            >
              {appointment.status}
            </Badge>
          </div>
        </div>
      ))}
    </div>
  )
}

import { cn } from "@/lib/utils"

