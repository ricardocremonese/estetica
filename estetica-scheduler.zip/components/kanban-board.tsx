"use client"

import { useState } from "react"
import {
  DndContext,
  type DragEndEvent,
  type DragOverEvent,
  type DragStartEvent,
  PointerSensor,
  useSensor,
  useSensors,
} from "@dnd-kit/core"
import { SortableContext, arrayMove, verticalListSortingStrategy } from "@dnd-kit/sortable"
import { KanbanColumn } from "./kanban-column"
import { ScrollArea, ScrollBar } from "./ui/scroll-area"

// Tipos para os agendamentos
export type Appointment = {
  id: string
  client: string
  service: string
  time: string
  professional: string
  status: "confirmado" | "pendente" | "cancelado"
  dayId: string
}

// Dados de exemplo
const initialAppointments: Appointment[] = [
  {
    id: "1",
    client: "Ana Silva",
    service: "Limpeza de Pele",
    time: "10:00",
    professional: "Dra. Carla",
    status: "confirmado",
    dayId: new Date().toISOString().split("T")[0],
  },
  {
    id: "2",
    client: "Mariana Costa",
    service: "Depilação",
    time: "14:00",
    professional: "Juliana",
    status: "confirmado",
    dayId: new Date().toISOString().split("T")[0],
  },
  {
    id: "3",
    client: "Carla Oliveira",
    service: "Massagem Relaxante",
    time: "16:30",
    professional: "Fernanda",
    status: "pendente",
    dayId: new Date().toISOString().split("T")[0],
  },
  {
    id: "4",
    client: "Patrícia Lima",
    service: "Design de Sobrancelhas",
    time: "11:00",
    professional: "Amanda",
    status: "confirmado",
    dayId: new Date(new Date().setDate(new Date().getDate() + 1)).toISOString().split("T")[0],
  },
  {
    id: "5",
    client: "Juliana Mendes",
    service: "Manicure e Pedicure",
    time: "15:00",
    professional: "Roberta",
    status: "confirmado",
    dayId: new Date(new Date().setDate(new Date().getDate() + 2)).toISOString().split("T")[0],
  },
]

type KanbanBoardProps = {
  days: Date[]
  currentDate: Date
}

export function KanbanBoard({ days, currentDate }: KanbanBoardProps) {
  const [appointments, setAppointments] = useState<Appointment[]>(initialAppointments)
  const [activeId, setActiveId] = useState<string | null>(null)

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
  )

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as string)
  }

  const handleDragOver = (event: DragOverEvent) => {
    const { active, over } = event

    if (!over) return

    const activeAppointment = appointments.find((a) => a.id === active.id)
    const overContainer = over.id.toString()

    if (!activeAppointment || activeAppointment.dayId === overContainer || !overContainer.includes("-day")) return

    setAppointments((appointments) =>
      appointments.map((appointment) =>
        appointment.id === activeAppointment.id
          ? { ...appointment, dayId: overContainer.replace("-day", "") }
          : appointment,
      ),
    )
  }

  const handleDragEnd = (event: DragEndEvent) => {
    setActiveId(null)

    const { active, over } = event

    if (!over) return

    const activeAppointment = appointments.find((a) => a.id === active.id)
    const overAppointment = appointments.find((a) => a.id === over.id)

    if (!activeAppointment || !overAppointment || activeAppointment.dayId !== overAppointment.dayId) return

    const activeIndex = appointments.findIndex((a) => a.id === active.id)
    const overIndex = appointments.findIndex((a) => a.id === over.id)

    if (activeIndex !== overIndex) {
      setAppointments(arrayMove(appointments, activeIndex, overIndex))
    }
  }

  // Filtramos para mostrar apenas 7 dias a partir da data atual
  const visibleDays = days.filter(
    (day) => day.getDate() >= currentDate.getDate() && day.getDate() < currentDate.getDate() + 7,
  )

  return (
    <DndContext sensors={sensors} onDragStart={handleDragStart} onDragOver={handleDragOver} onDragEnd={handleDragEnd}>
      <ScrollArea className="w-full whitespace-nowrap rounded-md border">
        <div className="flex p-4 gap-4">
          {visibleDays.map((day) => {
            const dayId = day.toISOString().split("T")[0]
            const dayAppointments = appointments.filter((a) => a.dayId === dayId)

            return (
              <SortableContext
                key={dayId}
                items={dayAppointments.map((a) => a.id)}
                strategy={verticalListSortingStrategy}
              >
                <KanbanColumn day={day} appointments={dayAppointments} isOver={activeId !== null} />
              </SortableContext>
            )
          })}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </DndContext>
  )
}

