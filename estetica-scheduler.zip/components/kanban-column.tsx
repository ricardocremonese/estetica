"use client"

import { useDroppable } from "@dnd-kit/core"
import { useSortable } from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"
import { formatDate, cn } from "@/lib/utils"
import type { Appointment } from "./kanban-board"
import { Badge } from "./ui/badge"
import { Card, CardContent } from "./ui/card"

type KanbanColumnProps = {
  day: Date
  appointments: Appointment[]
  isOver: boolean
}

export function KanbanColumn({ day, appointments, isOver }: KanbanColumnProps) {
  const dayId = day.toISOString().split("T")[0]
  const isToday = day.toDateString() === new Date().toDateString()

  const { setNodeRef, isOver: isColumnOver } = useDroppable({
    id: `${dayId}-day`,
  })

  return (
    <div
      ref={setNodeRef}
      className={cn(
        "flex flex-col w-[280px] rounded-lg border bg-card",
        isToday && "border-primary",
        isColumnOver && isOver && "border-primary bg-primary/5",
      )}
    >
      <div
        className={cn(
          "p-3 border-b font-medium flex items-center justify-between",
          isToday && "bg-primary/10 text-primary",
        )}
      >
        <div>
          <span className="text-sm">{formatDate(day)}</span>
          <span className="text-xs text-muted-foreground ml-2">
            {day.toLocaleDateString("pt-BR", { weekday: "short" })}
          </span>
        </div>
        <Badge variant="outline">{appointments.length}</Badge>
      </div>
      <div className="p-2 flex-1 space-y-2 min-h-[500px]">
        {appointments.map((appointment) => (
          <AppointmentCard key={appointment.id} appointment={appointment} />
        ))}
      </div>
    </div>
  )
}

type AppointmentCardProps = {
  appointment: Appointment
}

function AppointmentCard({ appointment }: AppointmentCardProps) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: appointment.id,
  })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  }

  return (
    <Card
      ref={setNodeRef}
      style={style}
      className={cn("appointment-card", isDragging && "dragging")}
      {...attributes}
      {...listeners}
    >
      <CardContent className="p-3 space-y-2">
        <div className="flex items-center justify-between">
          <Badge variant="outline" className="bg-primary/10">
            {appointment.time}
          </Badge>
          <Badge
            variant="outline"
            className={cn(
              appointment.status === "confirmado" && "bg-green-500/10 text-green-500",
              appointment.status === "pendente" && "bg-yellow-500/10 text-yellow-500",
              appointment.status === "cancelado" && "bg-red-500/10 text-red-500",
            )}
          >
            {appointment.status}
          </Badge>
        </div>
        <div>
          <h4 className="font-medium text-sm">{appointment.client}</h4>
          <p className="text-xs text-muted-foreground">{appointment.service}</p>
        </div>
        <div className="text-xs flex items-center justify-between">
          <span className="text-muted-foreground">Profissional:</span>
          <span>{appointment.professional}</span>
        </div>
      </CardContent>
    </Card>
  )
}

