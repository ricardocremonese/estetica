import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: Date): string {
  return new Intl.DateTimeFormat("pt-BR", {
    day: "numeric",
    month: "short",
  }).format(date)
}

export function getDaysInMonth(year: number, month: number): Date[] {
  const days = []
  const daysInMonth = new Date(year, month + 1, 0).getDate()

  for (let i = 1; i <= daysInMonth; i++) {
    days.push(new Date(year, month, i))
  }

  return days
}

export function getMonthName(month: number): string {
  return new Intl.DateTimeFormat("pt-BR", { month: "long" }).format(new Date(2000, month, 1))
}

export function getTimeSlots(): string[] {
  const slots = []
  for (let hour = 8; hour <= 19; hour++) {
    slots.push(`${hour}:00`)
    if (hour < 19) {
      slots.push(`${hour}:30`)
    }
  }
  return slots
}

