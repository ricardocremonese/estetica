// Este arquivo seria usado para configurar a conexão com o banco de dados
// Exemplo usando Prisma (você precisaria instalar o pacote @prisma/client)

import { PrismaClient } from "@prisma/client"

const globalForPrisma = global as unknown as { prisma: PrismaClient }

export const prisma =
  globalForPrisma.prisma ||
  new PrismaClient({
    log: ["query"],
  })

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma

