import { type NextRequest, NextResponse } from "next/server"

// Tipo para os dados recebidos do Typebot
type TypebotWebhookData = {
  client: {
    name: string
    phone: string
  }
  appointment: {
    service: string
    date: string
    time: string
    professional: string
  }
}

export async function POST(req: NextRequest) {
  try {
    // Obter os dados do corpo da requisição
    const data = (await req.json()) as TypebotWebhookData

    // Validar os dados recebidos
    if (!data.client || !data.appointment) {
      return NextResponse.json({ error: "Dados incompletos" }, { status: 400 })
    }

    // Aqui você processaria os dados e salvaria no banco de dados
    // Por exemplo, usando Prisma ou outro ORM

    // Simulando o processamento
    console.log("Agendamento recebido via webhook:", {
      client: data.client,
      appointment: data.appointment,
    })

    // Retornar uma resposta de sucesso
    return NextResponse.json(
      {
        success: true,
        message: "Agendamento recebido com sucesso",
        appointmentId: "appt_" + Date.now(), // Simulando um ID
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Erro ao processar webhook:", error)
    return NextResponse.json({ error: "Erro ao processar a solicitação" }, { status: 500 })
  }
}

