"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { MoreHorizontal, Plus, Search } from "lucide-react"
import { Badge } from "@/components/ui/badge"

// Dados de exemplo
const clients = [
  {
    id: "1",
    name: "Ana Silva",
    phone: "(11) 98765-4321",
    email: "ana.silva@email.com",
    lastVisit: "10/03/2024",
    totalVisits: 8,
    status: "ativo",
  },
  {
    id: "2",
    name: "Mariana Costa",
    phone: "(11) 91234-5678",
    email: "mariana.costa@email.com",
    lastVisit: "05/03/2024",
    totalVisits: 12,
    status: "ativo",
  },
  {
    id: "3",
    name: "Carla Oliveira",
    phone: "(11) 99876-5432",
    email: "carla.oliveira@email.com",
    lastVisit: "28/02/2024",
    totalVisits: 5,
    status: "ativo",
  },
  {
    id: "4",
    name: "Juliana Mendes",
    phone: "(11) 95555-4444",
    email: "juliana.mendes@email.com",
    lastVisit: "15/02/2024",
    totalVisits: 3,
    status: "ativo",
  },
  {
    id: "5",
    name: "Patrícia Lima",
    phone: "(11) 94444-3333",
    email: "patricia.lima@email.com",
    lastVisit: "10/01/2024",
    totalVisits: 1,
    status: "inativo",
  },
]

export default function ClientesPage() {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredClients = clients.filter(
    (client) =>
      client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.phone.includes(searchTerm) ||
      client.email.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Clientes</h2>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Novo Cliente
        </Button>
      </div>

      <div className="flex items-center space-x-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Buscar clientes..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button variant="outline">Filtros</Button>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>Telefone</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Última Visita</TableHead>
              <TableHead>Total de Visitas</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredClients.map((client) => (
              <TableRow key={client.id}>
                <TableCell className="font-medium">{client.name}</TableCell>
                <TableCell>{client.phone}</TableCell>
                <TableCell>{client.email}</TableCell>
                <TableCell>{client.lastVisit}</TableCell>
                <TableCell>{client.totalVisits}</TableCell>
                <TableCell>
                  <Badge
                    variant="outline"
                    className={
                      client.status === "ativo" ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                    }
                  >
                    {client.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Abrir menu</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Ações</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem>Ver detalhes</DropdownMenuItem>
                      <DropdownMenuItem>Editar cliente</DropdownMenuItem>
                      <DropdownMenuItem>Agendar serviço</DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-destructive">Excluir cliente</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

