"use client"

import { Badge } from "@/components/ui/badge"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CalendarIcon, ChevronLeft, ChevronRight, Plus } from "lucide-react"
import { cn, formatDate, getDaysInMonth, getMonthName } from "@/lib/utils"
import { KanbanBoard } from "@/components/kanban-board"
import { AppointmentDialog } from "@/components/appointment-dialog"

export default function AgendaPage() {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const currentYear = currentDate.getFullYear()
  const currentMonth = currentDate.getMonth()
  const daysInMonth = getDaysInMonth(currentYear, currentMonth)

  const goToPreviousMonth = () => {
    setCurrentDate(new Date(currentYear, currentMonth - 1, 1))
  }

  const goToNextMonth = () => {
    setCurrentDate(new Date(currentYear, currentMonth + 1, 1))
  }

  const goToToday = () => {
    setCurrentDate(new Date())
  }

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Agenda</h2>
        <Button onClick={() => setIsDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Novo Agendamento
        </Button>
      </div>

      <Tabs defaultValue="kanban" className="space-y-4">
        <div className="flex justify-between items-center">
          <TabsList>
            <TabsTrigger value="kanban">Kanban</TabsTrigger>
            <TabsTrigger value="calendar">Calendário</TabsTrigger>
            <TabsTrigger value="list">Lista</TabsTrigger>
          </TabsList>

          <div className="flex items-center space-x-2">
            <Button variant="outline" size="icon" onClick={goToPreviousMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" onClick={goToToday}>
              <CalendarIcon className="mr-2 h-4 w-4" />
              Hoje
            </Button>
            <Button variant="outline" size="icon" onClick={goToNextMonth}>
              <ChevronRight className="h-4 w-4" />
            </Button>
            <span className="text-sm font-medium">
              {getMonthName(currentMonth)} {currentYear}
            </span>
          </div>
        </div>

        <TabsContent value="kanban" className="space-y-4">
          <KanbanBoard days={daysInMonth} currentDate={currentDate} />
        </TabsContent>

        <TabsContent value="calendar" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Visualização de Calendário</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-4">
                {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((day) => (
                  <div key={day} className="text-center font-medium">
                    {day}
                  </div>
                ))}

                {Array.from({ length: new Date(currentYear, currentMonth, 1).getDay() }).map((_, i) => (
                  <div key={`empty-${i}`} className="h-24 rounded-lg border border-dashed"></div>
                ))}

                {daysInMonth.map((day) => {
                  const isToday = day.toDateString() === new Date().toDateString()
                  return (
                    <div
                      key={day.toString()}
                      className={cn(
                        "h-24 rounded-lg border p-2 transition-colors hover:border-primary",
                        isToday && "border-primary bg-primary/5",
                      )}
                    >
                      <div className="font-medium">{day.getDate()}</div>
                      <div className="mt-2 space-y-1">
                        <div className="text-xs rounded bg-primary/10 p-1 truncate">10:00 - Limpeza de Pele</div>
                        <div className="text-xs rounded bg-primary/10 p-1 truncate">14:30 - Massagem</div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="list" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Lista de Agendamentos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {daysInMonth.map((day) => (
                  <div
                    key={day.toString()}
                    className={cn(
                      "flex items-center justify-between rounded-lg border p-3",
                      day.toDateString() === new Date().toDateString() && "border-primary bg-primary/5",
                    )}
                  >
                    <div className="font-medium">{formatDate(day)}</div>
                    <div className="flex space-x-2">
                      <Badge variant="outline" className="bg-primary/10">
                        3 agendamentos
                      </Badge>
                      <Button variant="ghost" size="sm">
                        Ver detalhes
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <AppointmentDialog open={isDialogOpen} onOpenChange={setIsDialogOpen} />
    </div>
  )
}

