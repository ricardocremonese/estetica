document.addEventListener("DOMContentLoaded", () => {
  // Theme toggle
  const themeToggle = document.getElementById("theme-toggle")
  const themeIcon = themeToggle.querySelector("i")

  // Check for saved theme preference or respect OS preference
  const savedTheme = localStorage.getItem("theme")
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches

  if (savedTheme === "dark" || (!savedTheme && prefersDark)) {
    document.body.classList.add("dark-mode")
    themeIcon.classList.remove("bi-sun")
    themeIcon.classList.add("bi-moon")
  }

  themeToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode")

    if (document.body.classList.contains("dark-mode")) {
      localStorage.setItem("theme", "dark")
      themeIcon.classList.remove("bi-sun")
      themeIcon.classList.add("bi-moon")
    } else {
      localStorage.setItem("theme", "light")
      themeIcon.classList.remove("bi-moon")
      themeIcon.classList.add("bi-sun")
    }
  })

  // Date navigation
  const prevMonthBtn = document.getElementById("prev-month")
  const nextMonthBtn = document.getElementById("next-month")
  const todayBtn = document.getElementById("today-btn")
  const currentMonthYearElement = document.getElementById("current-month-year")

  const currentDate = new Date()
  let currentYear = currentDate.getFullYear()
  let currentMonth = currentDate.getMonth()

  // Update month/year display
  function updateMonthYearDisplay() {
    const monthNames = [
      "Janeiro",
      "Fevereiro",
      "Março",
      "Abril",
      "Maio",
      "Junho",
      "Julho",
      "Agosto",
      "Setembro",
      "Outubro",
      "Novembro",
      "Dezembro",
    ]
    currentMonthYearElement.textContent = `${monthNames[currentMonth]} ${currentYear}`
  }

  // Initialize month/year display
  updateMonthYearDisplay()

  // Previous month button
  prevMonthBtn.addEventListener("click", () => {
    currentMonth--
    if (currentMonth < 0) {
      currentMonth = 11
      currentYear--
    }
    updateMonthYearDisplay()
    renderKanbanBoard()
    renderCalendarView()
    renderListView()
  })

  // Next month button
  nextMonthBtn.addEventListener("click", () => {
    currentMonth++
    if (currentMonth > 11) {
      currentMonth = 0
      currentYear++
    }
    updateMonthYearDisplay()
    renderKanbanBoard()
    renderCalendarView()
    renderListView()
  })

  // Today button
  todayBtn.addEventListener("click", () => {
    const today = new Date()
    currentYear = today.getFullYear()
    currentMonth = today.getMonth()
    updateMonthYearDisplay()
    renderKanbanBoard()
    renderCalendarView()
    renderListView()
  })

  // Sample appointment data
  const appointments = [
    {
      id: "1",
      client: "Ana Silva",
      service: "Limpeza de Pele",
      time: "10:00",
      professional: "Dra. Carla",
      status: "confirmado",
      date: new Date().toISOString().split("T")[0],
    },
    {
      id: "2",
      client: "Mariana Costa",
      service: "Depilação",
      time: "14:00",
      professional: "Juliana",
      status: "confirmado",
      date: new Date().toISOString().split("T")[0],
    },
    {
      id: "3",
      client: "Carla Oliveira",
      service: "Massagem Relaxante",
      time: "16:30",
      professional: "Fernanda",
      status: "pendente",
      date: new Date().toISOString().split("T")[0],
    },
    {
      id: "4",
      client: "Patrícia Lima",
      service: "Design de Sobrancelhas",
      time: "11:00",
      professional: "Amanda",
      status: "confirmado",
      date: new Date(new Date().setDate(new Date().getDate() + 1)).toISOString().split("T")[0],
    },
    {
      id: "5",
      client: "Juliana Mendes",
      service: "Manicure e Pedicure",
      time: "15:00",
      professional: "Roberta",
      status: "confirmado",
      date: new Date(new Date().setDate(new Date().getDate() + 2)).toISOString().split("T")[0],
    },
  ]

  // Get days in month
  function getDaysInMonth(year, month) {
    const days = []
    const daysInMonth = new Date(year, month + 1, 0).getDate()

    for (let i = 1; i <= daysInMonth; i++) {
      days.push(new Date(year, month, i))
    }

    return days
  }

  // Format date
  function formatDate(date) {
    return date.toLocaleDateString("pt-BR", {
      day: "numeric",
      month: "short",
    })
  }

  // Render Kanban Board
  function renderKanbanBoard() {
    const kanbanBoard = document.getElementById("kanban-board")
    kanbanBoard.innerHTML = ""

    // Get days for current month
    const days = getDaysInMonth(currentYear, currentMonth)

    // Filter to show only 7 days starting from today or first day of month
    const today = new Date()
    let startDay = 0

    if (currentMonth === today.getMonth() && currentYear === today.getFullYear()) {
      startDay = today.getDate() - 1 // Adjust for 0-based index
    }

    const visibleDays = days.slice(startDay, startDay + 7)

    // Create columns for each day
    visibleDays.forEach((day) => {
      const dayId = day.toISOString().split("T")[0]
      const isToday = day.toDateString() === today.toDateString()

      // Create column
      const column = document.createElement("div")
      column.className = "kanban-column"
      column.id = `column-${dayId}`

      // Create column header
      const header = document.createElement("div")
      header.className = `kanban-column-header ${isToday ? "bg-primary text-white" : ""}`

      const headerContent = document.createElement("div")
      headerContent.innerHTML = `
        <span>${formatDate(day)}</span>
        <span class="text-muted small">${day.toLocaleDateString("pt-BR", { weekday: "short" })}</span>
      `

      const badge = document.createElement("span")
      badge.className = "badge bg-light text-dark"
      badge.textContent = appointments.filter((a) => a.date === dayId).length

      header.appendChild(headerContent)
      header.appendChild(badge)

      // Create column body
      const body = document.createElement("div")
      body.className = "kanban-column-body"
      body.id = `column-body-${dayId}`

      // Add appointments for this day
      const dayAppointments = appointments.filter((a) => a.date === dayId)

      dayAppointments.forEach((appointment) => {
        const appointmentElement = createAppointmentCard(appointment)
        body.appendChild(appointmentElement)
      })

      // Add column to board
      column.appendChild(header)
      column.appendChild(body)
      kanbanBoard.appendChild(column)

      // Initialize Sortable for this column
      new Sortable(body, {
        group: "appointments",
        animation: 150,
        ghostClass: "appointment-ghost",
        chosenClass: "appointment-chosen",
        dragClass: "appointment-drag",
        onEnd: (evt) => {
          const appointmentId = evt.item.dataset.id
          const newColumnId = evt.to.id.replace("column-body-", "")

          // Update appointment date
          const appointmentIndex = appointments.findIndex((a) => a.id === appointmentId)
          if (appointmentIndex !== -1) {
            appointments[appointmentIndex].date = newColumnId
          }
        },
      })
    })
  }

  // Create appointment card
  function createAppointmentCard(appointment) {
    const card = document.createElement("div")
    card.className = "card kanban-item"
    card.dataset.id = appointment.id

    const statusClass =
      appointment.status === "confirmado"
        ? "bg-success"
        : appointment.status === "pendente"
          ? "bg-warning text-dark"
          : "bg-danger"

    card.innerHTML = `
      <div class="card-body p-2">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <span class="badge bg-primary">${appointment.time}</span>
          <span class="badge ${statusClass}">${appointment.status}</span>
        </div>
        <h6 class="card-subtitle mb-1">${appointment.client}</h6>
        <p class="card-text small text-muted">${appointment.service}</p>
        <div class="d-flex justify-content-between align-items-center mt-2">
          <small class="text-muted">Profissional:</small>
          <small>${appointment.professional}</small>
        </div>
      </div>
    `

    return card
  }

  // Render Calendar View
  function renderCalendarView() {
    const calendarBody = document.getElementById("calendar-body")
    calendarBody.innerHTML = ""

    const today = new Date()
    const firstDay = new Date(currentYear, currentMonth, 1).getDay()
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate()

    // Add empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      const emptyDay = document.createElement("div")
      emptyDay.className = "calendar-day-empty"
      calendarBody.appendChild(emptyDay)
    }

    // Add days of the month
    for (let i = 1; i <= daysInMonth; i++) {
      const currentDay = new Date(currentYear, currentMonth, i)
      const dayId = currentDay.toISOString().split("T")[0]
      const isToday = currentDay.toDateString() === today.toDateString()

      const dayElement = document.createElement("div")
      dayElement.className = `calendar-day ${isToday ? "today" : ""}`

      const dayHeader = document.createElement("div")
      dayHeader.className = "calendar-day-header"
      dayHeader.textContent = i

      const dayAppointments = appointments.filter((a) => a.date === dayId)

      dayElement.appendChild(dayHeader)

      // Add appointments for this day (max 3)
      dayAppointments.slice(0, 3).forEach((appointment) => {
        const appointmentElement = document.createElement("div")
        appointmentElement.className = "calendar-appointment small"
        appointmentElement.innerHTML = `
          <div class="text-truncate bg-primary-light p-1 rounded mb-1">
            ${appointment.time} - ${appointment.service}
          </div>
        `
        dayElement.appendChild(appointmentElement)
      })

      // Add "more" indicator if there are more than 3 appointments
      if (dayAppointments.length > 3) {
        const moreElement = document.createElement("div")
        moreElement.className = "text-center small text-muted"
        moreElement.textContent = `+ ${dayAppointments.length - 3} mais`
        dayElement.appendChild(moreElement)
      }

      calendarBody.appendChild(dayElement)
    }
  }

  // Render List View
  function renderListView() {
    const appointmentList = document.getElementById("appointment-list")
    appointmentList.innerHTML = ""

    // Get days for current month
    const days = getDaysInMonth(currentYear, currentMonth)

    days.forEach((day) => {
      const dayId = day.toISOString().split("T")[0]
      const dayAppointments = appointments.filter((a) => a.date === dayId)

      if (dayAppointments.length > 0) {
        const listItem = document.createElement("div")
        listItem.className = "list-group-item"

        const dayHeader = document.createElement("div")
        dayHeader.className = "d-flex justify-content-between align-items-center"

        const dayTitle = document.createElement("h6")
        dayTitle.className = "mb-0"
        dayTitle.textContent = day.toLocaleDateString("pt-BR", {
          weekday: "long",
          day: "numeric",
          month: "long",
        })

        const badge = document.createElement("span")
        badge.className = "badge bg-primary"
        badge.textContent = `${dayAppointments.length} agendamentos`

        dayHeader.appendChild(dayTitle)
        dayHeader.appendChild(badge)
        listItem.appendChild(dayHeader)

        // Add appointments for this day
        const appointmentsContainer = document.createElement("div")
        appointmentsContainer.className = "mt-2"

        dayAppointments.forEach((appointment) => {
          const appointmentElement = document.createElement("div")
          appointmentElement.className = "appointment-item"

          const statusClass =
            appointment.status === "confirmado"
              ? "bg-success"
              : appointment.status === "pendente"
                ? "bg-warning text-dark"
                : "bg-danger"

          appointmentElement.innerHTML = `
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <span class="badge bg-primary">${appointment.time}</span>
                <span class="ms-2 fw-medium">${appointment.client}</span>
                <span class="ms-2 text-muted small">${appointment.service}</span>
              </div>
              <div>
                <span class="badge ${statusClass}">${appointment.status}</span>
                <button class="btn btn-sm btn-outline-secondary ms-2">
                  <i class="bi bi-three-dots-vertical"></i>
                </button>
              </div>
            </div>
          `

          appointmentsContainer.appendChild(appointmentElement)
        })

        listItem.appendChild(appointmentsContainer)
        appointmentList.appendChild(listItem)
      }
    })
  }

  // Populate time slots in appointment form
  function populateTimeSlots() {
    const timeSelect = document.getElementById("appointment-time")
    timeSelect.innerHTML = '<option value="" selected disabled>Selecione</option>'

    // Generate time slots from 8:00 to 19:00 with 30 minute intervals
    for (let hour = 8; hour <= 19; hour++) {
      // Add hour:00
      const hourOption = document.createElement("option")
      hourOption.value = `${hour}:00`
      hourOption.textContent = `${hour}:00`
      timeSelect.appendChild(hourOption)

      // Add hour:30 if not the last hour
      if (hour < 19) {
        const halfHourOption = document.createElement("option")
        halfHourOption.value = `${hour}:30`
        halfHourOption.textContent = `${hour}:30`
        timeSelect.appendChild(halfHourOption)
      }
    }
  }

  // Initialize time slots
  populateTimeSlots()

  // Save appointment
  document.getElementById("save-appointment").addEventListener("click", () => {
    const clientName = document.getElementById("client-name").value
    const clientPhone = document.getElementById("client-phone").value
    const service = document.getElementById("service").value
    const professional = document.getElementById("professional").value
    const date = document.getElementById("appointment-date").value
    const time = document.getElementById("appointment-time").value

    if (!clientName || !clientPhone || !service || !professional || !date || !time) {
      alert("Por favor, preencha todos os campos obrigatórios.")
      return
    }

    // Create new appointment
    const newAppointment = {
      id: Date.now().toString(),
      client: clientName,
      service: document.getElementById("service").options[document.getElementById("service").selectedIndex].text,
      time: time,
      professional:
        document.getElementById("professional").options[document.getElementById("professional").selectedIndex].text,
      status: "confirmado",
      date: date,
    }

    // Add to appointments array
    appointments.push(newAppointment)

    // Refresh views
    renderKanbanBoard()
    renderCalendarView()
    renderListView()

    // Close modal
    const modalElement = document.getElementById("appointmentModal")
    const modal = bootstrap.Modal.getInstance(modalElement)
    modal.hide()

    // Reset form
    document.getElementById("appointment-form").reset()
  })

  // Initialize views
  renderKanbanBoard()
  renderCalendarView()
  renderListView()

  // Webhook handler for Typebot integration
  // This would be implemented on the server side
  // Here's a mock implementation for demonstration
  function handleWebhook(data) {
    // Create new appointment from webhook data
    const newAppointment = {
      id: Date.now().toString(),
      client: data.client.name,
      service: data.appointment.service,
      time: data.appointment.time,
      professional: data.appointment.professional,
      status: "pendente",
      date: data.appointment.date,
    }

    // Add to appointments array
    appointments.push(newAppointment)

    // Refresh views
    renderKanbanBoard()
    renderCalendarView()
    renderListView()

    // Return success response
    return {
      success: true,
      message: "Agendamento recebido com sucesso",
      appointmentId: newAppointment.id,
    }
  }

  // Example of webhook data from Typebot
  const webhookExample = {
    client: {
      name: "Maria Santos",
      phone: "(11) 98765-4321",
    },
    appointment: {
      service: "Limpeza de Pele",
      date: "2023-03-15",
      time: "14:30",
      professional: "Dra. Carla",
    },
  }

  // For demonstration purposes only
  // console.log('Webhook example:', handleWebhook(webhookExample));

  // Initialize SortableJS
  const Sortable = window.Sortable

  // Initialize Bootstrap
  const bootstrap = window.bootstrap
})

