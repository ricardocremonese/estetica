document.addEventListener("DOMContentLoaded", () => {
  // Theme toggle
  const themeToggle = document.getElementById("theme-toggle")
  const themeIcon = themeToggle.querySelector("i")

  // Check for saved theme preference or respect OS preference
  const savedTheme = localStorage.getItem("theme")
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches

  if (savedTheme === "dark" || (!savedTheme && prefersDark)) {
    document.body.classList.add("dark-mode")
    themeIcon.classList.remove("bi-sun")
    themeIcon.classList.add("bi-moon")
  }

  themeToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode")

    if (document.body.classList.contains("dark-mode")) {
      localStorage.setItem("theme", "dark")
      themeIcon.classList.remove("bi-sun")
      themeIcon.classList.add("bi-moon")
    } else {
      localStorage.setItem("theme", "light")
      themeIcon.classList.remove("bi-moon")
      themeIcon.classList.add("bi-sun")
    }
  })

  // Sample clients data
  const clients = [
    {
      id: "1",
      name: "Ana Silva",
      phone: "(11) 98765-4321",
      email: "ana.silva@email.com",
      lastVisit: "10/03/2024",
      totalVisits: 8,
      status: "ativo",
    },
    {
      id: "2",
      name: "Mariana Costa",
      phone: "(11) 91234-5678",
      email: "mariana.costa@email.com",
      lastVisit: "05/03/2024",
      totalVisits: 12,
      status: "ativo",
    },
    {
      id: "3",
      name: "Carla Oliveira",
      phone: "(11) 99876-5432",
      email: "carla.oliveira@email.com",
      lastVisit: "28/02/2024",
      totalVisits: 5,
      status: "ativo",
    },
    {
      id: "4",
      name: "Juliana Mendes",
      phone: "(11) 95555-4444",
      email: "juliana.mendes@email.com",
      lastVisit: "15/02/2024",
      totalVisits: 3,
      status: "ativo",
    },
    {
      id: "5",
      name: "Patrícia Lima",
      phone: "(11) 94444-3333",
      email: "patricia.lima@email.com",
      lastVisit: "10/01/2024",
      totalVisits: 1,
      status: "inativo",
    },
  ]

  // Render clients table
  function renderClientsTable(clientsData) {
    const tableBody = document.getElementById("clients-table-body")
    tableBody.innerHTML = ""

    clientsData.forEach((client) => {
      const row = document.createElement("tr")

      const statusClass = client.status === "ativo" ? "bg-success" : "bg-danger"

      row.innerHTML = `
        <td>${client.name}</td>
        <td>${client.phone}</td>
        <td>${client.email}</td>
        <td>${client.lastVisit}</td>
        <td>${client.totalVisits}</td>
        <td><span class="badge ${statusClass}">${client.status}</span></td>
        <td>
          <div class="dropdown">
            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="bi bi-three-dots-vertical"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><a class="dropdown-item" href="#">Ver detalhes</a></li>
              <li><a class="dropdown-item" href="#">Editar cliente</a></li>
              <li><a class="dropdown-item" href="#">Agendar serviço</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item text-danger" href="#">Excluir cliente</a></li>
            </ul>
          </div>
        </td>
      `

      tableBody.appendChild(row)
    })
  }

  // Initialize clients table
  renderClientsTable(clients)

  // Search functionality
  const searchInput = document.getElementById("search-client")
  searchInput.addEventListener("input", function () {
    const searchTerm = this.value.toLowerCase()

    const filteredClients = clients.filter(
      (client) =>
        client.name.toLowerCase().includes(searchTerm) ||
        client.phone.includes(searchTerm) ||
        client.email.toLowerCase().includes(searchTerm),
    )

    renderClientsTable(filteredClients)
  })

  // Save new client
  document.getElementById("save-client").addEventListener("click", () => {
    const name = document.getElementById("name").value
    const phone = document.getElementById("phone").value
    const email = document.getElementById("email").value
    const address = document.getElementById("address").value
    const birthdate = document.getElementById("birthdate").value

    if (!name || !phone || !email) {
      alert("Por favor, preencha todos os campos obrigatórios.")
      return
    }

    // Create new client
    const newClient = {
      id: Date.now().toString(),
      name: name,
      phone: phone,
      email: email,
      address: address,
      birthdate: birthdate,
      lastVisit: "-",
      totalVisits: 0,
      status: "ativo",
    }

    // Add to clients array
    clients.push(newClient)

    // Refresh table
    renderClientsTable(clients)

    // Close modal
    const clientModal = document.getElementById("clientModal")
    const modal = bootstrap.Modal.getInstance(clientModal)
    modal.hide()

    // Reset form
    document.getElementById("client-form").reset()
  })
})

