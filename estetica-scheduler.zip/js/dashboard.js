document.addEventListener("DOMContentLoaded", () => {
  // Set current date
  const currentDateElement = document.getElementById("current-date")
  const today = new Date()
  currentDateElement.textContent = today.toLocaleDateString("pt-BR", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  // Theme toggle
  const themeToggle = document.getElementById("theme-toggle")
  const themeIcon = themeToggle.querySelector("i")

  // Check for saved theme preference or respect OS preference
  const savedTheme = localStorage.getItem("theme")
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches

  if (savedTheme === "dark" || (!savedTheme && prefersDark)) {
    document.body.classList.add("dark-mode")
    themeIcon.classList.remove("bi-sun")
    themeIcon.classList.add("bi-moon")
  }

  themeToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode")

    if (document.body.classList.contains("dark-mode")) {
      localStorage.setItem("theme", "dark")
      themeIcon.classList.remove("bi-sun")
      themeIcon.classList.add("bi-moon")
    } else {
      localStorage.setItem("theme", "light")
      themeIcon.classList.remove("bi-moon")
      themeIcon.classList.add("bi-sun")
    }
  })

  // Initialize mini calendar
  const miniCalendarElement = document.getElementById("mini-calendar")
  const selectedDateElement = document.getElementById("selected-date")

  // Create calendar grid
  const daysOfWeek = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"]
  const calendarHeader = document.createElement("div")
  calendarHeader.className = "calendar-header d-flex justify-content-between"

  daysOfWeek.forEach((day) => {
    const dayElement = document.createElement("div")
    dayElement.className = "calendar-day-name"
    dayElement.textContent = day
    calendarHeader.appendChild(dayElement)
  })

  miniCalendarElement.appendChild(calendarHeader)

  // Create calendar body
  const calendarBody = document.createElement("div")
  calendarBody.className = "calendar-body d-flex flex-wrap"

  // Get current month days
  const year = today.getFullYear()
  const month = today.getMonth()
  const firstDay = new Date(year, month, 1).getDay()
  const daysInMonth = new Date(year, month + 1, 0).getDate()

  // Add empty cells for days before the first day of the month
  for (let i = 0; i < firstDay; i++) {
    const emptyDay = document.createElement("div")
    emptyDay.className = "calendar-day-empty"
    calendarBody.appendChild(emptyDay)
  }

  // Add days of the month
  for (let i = 1; i <= daysInMonth; i++) {
    const dayElement = document.createElement("div")
    dayElement.className = "calendar-day"
    dayElement.textContent = i

    // Highlight today
    if (i === today.getDate()) {
      dayElement.classList.add("today")
    }

    // Add click event to select date
    dayElement.addEventListener("click", () => {
      // Remove selected class from all days
      document.querySelectorAll(".calendar-day").forEach((day) => {
        day.classList.remove("selected")
      })

      // Add selected class to clicked day
      dayElement.classList.add("selected")

      // Update selected date text
      const selectedDate = new Date(year, month, i)
      selectedDateElement.textContent = selectedDate.toLocaleDateString("pt-BR", {
        weekday: "long",
        day: "numeric",
        month: "long",
      })
    })

    calendarBody.appendChild(dayElement)
  }

  miniCalendarElement.appendChild(calendarBody)
})

